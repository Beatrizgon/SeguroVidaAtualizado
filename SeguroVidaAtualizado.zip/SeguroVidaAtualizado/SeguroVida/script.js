const detalhesBasico = [
    "Seguro de vida acessível",
    "Assistência 24h",
    "Cobertura básica"
  ];

  const detalhesTop = [
    "Seguro de vida completo",
    "Assistência 24h com suporte premium",
    "Cobertura para acidentes"
  ];

  const detalhesPremium = [
    "Seguro de vida completo com planos personalizados",
    "Assistência 24h VIP",
    "Cobertura ampla para toda a família"
  ];

  function showModal(title, subtitle, price, details) {
    document.getElementById('modalTitle').innerText = title;
    document.getElementById('modalSubtitle').innerText = subtitle;
    document.getElementById('modalPrice').innerText = price;

    const modalDetails = document.getElementById('modalDetails');
    modalDetails.innerHTML = '';
    details.forEach(function (detail) {
      let li = document.createElement('li');
      li.textContent = detail;
      modalDetails.appendChild(li);
    });

    $('#planModal').modal('show');
  }